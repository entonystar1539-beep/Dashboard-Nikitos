# ⚡ Быстрое решение для сохранения БД

## Вариант 1: Git (Самый быстрый - 1 минута)

```bash
git add prisma/data.db .env
git commit -m "chore: Add database to repo"
git push
```

**Готово!** БД теперь в репозитории и не потеряется при деплое.

**После изменений данных:**
```bash
git add prisma/data.db
git commit -m "chore: Update DB"
git push
```

---

## Вариант 2: Railway CLI + Volume

```bash
# Установите CLI (если еще нет)
npm install -g @railway/cli

# Войдите в Railway
railway login

# Перейдите в проект
cd /home/user/D7-Dash
railway link

# ПРОВЕРЬТЕ, есть ли volumes
railway volume list

# Если нет - создайте
railway volume create database-storage -m /data

# Установите переменную
railway variables set DATABASE_URL="file:/data/data.db"

# Скопируйте БД на volume
railway run cp prisma/data.db /data/data.db

# Деплой
git push
```

---

## Вариант 3: Turso (SQLite в облаке)

### Быстрый старт:

1. **Зайдите на https://turso.tech** и зарегистрируйтесь

2. **Установите CLI:**
```bash
curl -sSfL https://get.tur.so/install.sh | bash
```

3. **Создайте БД:**
```bash
turso auth login
turso db create d7-dash
```

4. **Получите credentials:**
```bash
# URL базы данных
turso db show d7-dash --url
# Скопируйте вывод

# Токен
turso db tokens create d7-dash
# Скопируйте токен
```

5. **Добавьте в Railway Variables:**
```
DATABASE_URL=libsql://[ваш-url].turso.io
DATABASE_AUTH_TOKEN=[ваш-токен]
```

6. **Обновите код** (если нужно):
```typescript
// src/lib/prisma.ts - уже должно работать
// Turso совместим с SQLite
```

7. **Загрузите данные:**
```bash
# Экспортируйте текущую БД
sqlite3 prisma/data.db .dump > backup.sql

# Загрузите в Turso
turso db shell d7-dash < backup.sql
```

**Готово!** Теперь БД в облаке и доступна всегда.

---

## 🎯 Что выбрать?

**Для быстрого запуска (прямо сейчас):**
✅ **Вариант 1: Git** - работает за 1 минуту

**Для production (на будущее):**
✅ **Вариант 3: Turso** - профессионально, бесплатно до 500MB

**Если найдете Volumes в Railway:**
✅ **Вариант 2: Railway Volume** - идеально для Railway

---

## ⚡ СДЕЛАЙТЕ ПРЯМО СЕЙЧАС:

```bash
# 1. Добавьте БД в Git (временно)
git add prisma/data.db
git commit -m "chore: Add database to repository"
git push

# 2. Проверьте деплой в Railway
# Откройте приложение - данные должны быть

# 3. Потом настроите Turso или найдете Volumes
```

**Результат:** Приложение работает, данные не теряются! 🎉
