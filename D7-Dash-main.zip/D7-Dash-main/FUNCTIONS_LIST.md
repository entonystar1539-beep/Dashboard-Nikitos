# Список всех функций в проекте D7-Dash

## 📚 Содержание
1. [Библиотеки (src/lib)](#библиотеки-srclib)
2. [API Routes (src/app/api)](#api-routes-srcappapi)
3. [Компоненты (src/components)](#компоненты-srccomponents)
4. [Скрипты (scripts)](#скрипты-scripts)
5. [Страницы (src/app)](#страницы-srcapp)

---

## Библиотеки (src/lib)

### 1. **auth.ts** - Аутентификация и авторизация

#### `hashPassword(password: string): Promise<string>`
- **Описание**: Хеширует пароль с использованием scrypt
- **Параметры**: `password` - пароль в открытом виде
- **Возвращает**: Promise с хешированным паролем (base64)
- **Использование**: Регистрация пользователей, смена пароля

#### `verifyPassword(password: string, hash: string): Promise<boolean>`
- **Описание**: Проверяет соответствие пароля и хеша
- **Параметры**: 
  - `password` - пароль для проверки
  - `hash` - сохраненный хеш
- **Возвращает**: Promise<boolean> - true если совпадает
- **Использование**: Вход в систему

#### `createSession(userId: string): Promise<string>`
- **Описание**: Создает новую сессию для пользователя
- **Параметры**: `userId` - ID пользователя
- **Возвращает**: Promise<string> - токен сессии
- **Использование**: После успешного входа

#### `deleteSession(token: string): Promise<void>`
- **Описание**: Удаляет сессию пользователя
- **Параметры**: `token` - токен сессии
- **Использование**: Выход из системы

#### `getSession(token: string): Promise<Session | null>`
- **Описание**: Получает данные сессии по токену
- **Параметры**: `token` - токен сессии
- **Возвращает**: Promise<Session | null>

#### `getCurrentUser(): Promise<User | null>`
- **Описание**: Получает текущего авторизованного пользователя
- **Возвращает**: Promise<User | null>
- **Использование**: Проверка авторизации на страницах

#### `requireAuth(): Promise<User>`
- **Описание**: Middleware для проверки авторизации
- **Возвращает**: Promise<User> или выбрасывает ошибку
- **Throws**: Ошибка 401 если не авторизован

#### `requireEditorAuth(): Promise<User>`
- **Описание**: Проверяет права уровня editor или выше
- **Возвращает**: Promise<User> (editor/admin)
- **Throws**: Ошибка 403 если недостаточно прав

#### `requireAdminAuth(): Promise<User>`
- **Описание**: Проверяет права администратора
- **Возвращает**: Promise<User> (admin)
- **Throws**: Ошибка 403 если не admin

#### `ensureDefaultAdmin(): Promise<void>`
- **Описание**: Создает админа по умолчанию если нет пользователей
- **⚠️ ПРОБЛЕМА**: Использует хардкоженный пароль "admin123"
- **Использование**: Инициализация системы

---

### 2. **calculations.ts** - Бизнес-расчеты

#### `calculateAgencyFee(spend: number, agencyType: string): number`
- **Описание**: Рассчитывает комиссию агентства
- **Параметры**:
  - `spend` - сумма расходов
  - `agencyType` - тип агентства (TRUST/другие)
- **Возвращает**: Сумма комиссии (9% для TRUST, 8% для остальных)
- **Пример**: `calculateAgencyFee(1000, 'TRUST')` → 90

#### `calculatePayrollFdHandler(fdCount: number, fdAmount: number): number`
- **Описание**: Расчет ФОТ для обработчика ФД по уровням
- **Параметры**:
  - `fdCount` - количество ФД
  - `fdAmount` - сумма ФД
- **Возвращает**: Сумма выплаты
- **Логика**: 
  - 0-15 ФД: $3/ФД
  - 16-25 ФД: $4/ФД
  - 26+ ФД: $5/ФД

#### `calculatePayrollRdHandler(rdAmount: number): number`
- **Описание**: Расчет ФОТ для обработчика РД
- **Параметры**: `rdAmount` - сумма РД
- **Возвращает**: 4% от суммы РД

#### `calculatePayrollBuyer(spend: number): number`
- **Описание**: Расчет ФОТ для баера
- **Параметры**: `spend` - спенд
- **Возвращает**: 12% от спенда

#### `calculateRoi(profit: number, spend: number): number`
- **Описание**: Расчет ROI
- **Параметры**:
  - `profit` - чистая прибыль
  - `spend` - спенд
- **Возвращает**: ROI в процентах
- **Формула**: `(profit / spend) * 100`

#### `calculateAllMetrics(data: DailyMetricsInput): DailyMetrics`
- **Описание**: Комплексный расчет всех метрик за день
- **Параметры**: `data` - входные данные метрик
- **Возвращает**: Полный объект с рассчитанными метриками
- **Включает**:
  - Конверсию валют
  - Расчет комиссий
  - Расчет прибыли
  - Расчет ROI
  - Расчет балансов

---

### 3. **prisma.ts** - Подключение к БД

#### `getPrismaClient(): PrismaClient`
- **Описание**: Получает singleton инстанс Prisma
- **Возвращает**: PrismaClient
- **Особенность**: Использует Proxy для обработки запросов

---

### 4. **utils.ts** - Утилиты

#### `cn(...inputs: ClassValue[]): string`
- **Описание**: Объединяет CSS классы с Tailwind
- **Параметры**: Массив классов
- **Возвращает**: Объединенная строка классов
- **Использование**: Условные стили в компонентах

#### `formatCurrency(amount: number, currency?: string): string`
- **Описание**: Форматирует число как валюту
- **Параметры**:
  - `amount` - сумма
  - `currency` - код валюты (по умолчанию USD)
- **Возвращает**: Отформатированная строка
- **Пример**: `formatCurrency(1234.56, 'USD')` → "$1,234.56"

#### `formatDate(date: Date | string, format?: string): string`
- **Описание**: Форматирует дату
- **Параметры**:
  - `date` - дата
  - `format` - формат (по умолчанию 'dd.MM.yyyy')
- **Возвращает**: Отформатированная дата

---

### 5. **payroll-calculator.ts** - Расчет зарплат

#### `calculateEmployeePayroll(employee: Employee, metrics: DailyMetrics[]): PayrollCalculation`
- **Описание**: Рассчитывает зарплату сотрудника за период
- **Параметры**:
  - `employee` - данные сотрудника
  - `metrics` - метрики за период
- **Возвращает**: Детализированный расчет зарплаты
- **Учитывает**: Роль, ставку, схему выплат

---

### 6. **google-sheets.ts** - Интеграция с Google Sheets

#### `getGoogleSheetsClient(): sheets_v4.Sheets`
- **Описание**: Создает клиент Google Sheets API
- **Возвращает**: Sheets клиент
- **Требует**: Учетные данные в переменных окружения

#### `syncDataToSheets(spreadsheetId: string, data: any[]): Promise<void>`
- **Описание**: Синхронизирует данные в Google Sheets
- **Параметры**:
  - `spreadsheetId` - ID таблицы
  - `data` - данные для записи

#### `readFromSheets(spreadsheetId: string, range: string): Promise<any[][]>`
- **Описание**: Читает данные из Google Sheets
- **Параметры**:
  - `spreadsheetId` - ID таблицы
  - `range` - диапазон ячеек (A1:Z100)
- **Возвращает**: Двумерный массив значений

---

### 7. **htx-api.ts** - Интеграция с HTX (Huobi)

#### `getHtxBalance(): Promise<WalletBalance>`
- **Описание**: Получает баланс кошелька HTX
- **Возвращает**: Promise<WalletBalance>
- **Требует**: HTX_API_KEY, HTX_SECRET_KEY

#### `getHtxTransactions(startDate?: Date, endDate?: Date): Promise<Transaction[]>`
- **Описание**: Получает историю транзакций HTX
- **Параметры**:
  - `startDate` - начальная дата
  - `endDate` - конечная дата
- **Возвращает**: Массив транзакций

---

### 8. **moralis-api.ts** - Интеграция с Moralis (Web3)

#### `getMoralisWalletBalance(address: string): Promise<WalletBalance>`
- **Описание**: Получает баланс Web3 кошелька через Moralis
- **Параметры**: `address` - адрес кошелька
- **Возвращает**: Promise<WalletBalance>

---

### 9. **bsc-api.ts** - Интеграция с Binance Smart Chain

#### `getBscWalletBalance(address: string): Promise<WalletBalance>`
- **Описание**: Получает баланс BSC кошелька
- **Параметры**: `address` - адрес кошелька
- **Возвращает**: Promise<WalletBalance>

---

## API Routes (src/app/api)

### Аутентификация

#### `POST /api/auth/login`
- **Описание**: Вход в систему
- **Body**: `{ username: string, password: string }`
- **Возвращает**: `{ user: User, token: string }`
- **Ошибки**: 401 при неверных данных

#### `POST /api/auth/logout`
- **Описание**: Выход из системы
- **Требует**: Авторизацию
- **Возвращает**: `{ success: true }`

#### `GET /api/auth/me`
- **Описание**: Получить данные текущего пользователя
- **Требует**: Авторизацию
- **Возвращает**: User объект

---

### Dashboard и Метрики

#### `GET /api/dashboard`
- **Описание**: Получить данные для главного дашборда
- **Query параметры**: 
  - `startDate` - начальная дата (опционально)
  - `endDate` - конечная дата (опционально)
- **Возвращает**: 
  ```typescript
  {
    summary: {
      totalRevenue: number,
      totalSpend: number,
      totalExpenses: number,
      netProfit: number,
      roi: number
    },
    countrySummaries: CountrySummary[],
    recentMetrics: DailyMetrics[]
  }
  ```

#### `GET /api/metrics`
- **Описание**: Получить метрики за период
- **Query**: `startDate`, `endDate`, `countryId`
- **Возвращает**: DailyMetrics[]

#### `POST /api/metrics`
- **Описание**: Создать/обновить метрики
- **Требует**: Editor права
- **Body**: DailyMetricsInput
- **Возвращает**: DailyMetrics

---

### Страны

#### `GET /api/countries`
- **Описание**: Список всех стран
- **Возвращает**: Country[]

#### `POST /api/countries`
- **Описание**: Создать новую страну
- **Требует**: Admin права
- **Body**: `{ name: string, code: string, currency: string }`

#### `PATCH /api/countries`
- **Описание**: Обновить страну
- **Требует**: Admin права

---

### Расходы

#### `GET /api/expenses`
- **Описание**: Получить расходы
- **Query**: `startDate`, `endDate`, `category`
- **Возвращает**: Expense[]

#### `POST /api/expenses`
- **Описание**: Создать расход
- **Требует**: Editor права
- **Body**: ExpenseInput
- **Возвращает**: Expense

---

### Зарплаты (Payroll)

#### `GET /api/payroll`
- **Описание**: Получить записи ФОТ
- **Query**: `startDate`, `endDate`, `employeeId`
- **Возвращает**: PayrollRecord[]

#### `POST /api/payroll`
- **Описание**: Создать запись ФОТ
- **Требует**: Editor права
- **Body**: PayrollInput

#### `GET /api/payroll/summary`
- **Описание**: Сводка по ФОТ
- **Query**: `month`, `year`
- **Возвращает**: PayrollSummary

---

### Покупки (Buying)

#### `GET /api/buying`
- **Описание**: Получить данные покупок
- **Возвращает**: BuyingData[]

#### `POST /api/buying`
- **Описание**: Создать запись покупки
- **Требует**: Editor права

#### `GET /api/buying/summary`
- **Описание**: Сводка по покупкам
- **Возвращает**: BuyingSummary

---

### Кабинеты

#### `GET /api/cabinets`
- **Описание**: Список рекламных кабинетов
- **Возвращает**: AdAccount[]

#### `POST /api/cabinets`
- **Описание**: Создать кабинет
- **Требует**: Admin права

#### `PATCH /api/cabinets/[id]`
- **Описание**: Обновить кабинет
- **Требует**: Admin права

#### `DELETE /api/cabinets/[id]`
- **Описание**: Удалить кабинет
- **Требует**: Admin права

---

### Сотрудники

#### `GET /api/employees`
- **Описание**: Список сотрудников
- **Возвращает**: Employee[]

#### `POST /api/employees`
- **Описание**: Добавить сотрудника
- **Требует**: Admin права

---

### Кошельки

#### `GET /api/wallet/country-wallets`
- **Описание**: Кошельки стран
- **Возвращает**: CountryWallet[]

#### `GET /api/wallet/agency-wallets`
- **Описание**: Кошельки агентств
- **Возвращает**: AgencyWallet[]

#### `POST /api/wallet/sync`
- **Описание**: Синхронизация балансов кошельков
- **Требует**: Editor права

#### `GET /api/wallet/transactions`
- **Описание**: История транзакций кошельков
- **Query**: `startDate`, `endDate`, `walletId`

#### `PATCH /api/wallet/transactions/[id]`
- **Описание**: Обновить транзакцию
- **Требует**: Editor права

---

### HTX API

#### `GET /api/htx/balance`
- **Описание**: Получить баланс HTX
- **Возвращает**: WalletBalance

#### `GET /api/htx/transactions`
- **Описание**: История транзакций HTX
- **Query**: `startDate`, `endDate`

---

### Балансы

#### `GET /api/balances`
- **Описание**: Текущие балансы всех счетов
- **Возвращает**: Balance[]

#### `GET /api/balances/transactions`
- **Описание**: История изменений балансов

---

### Google Sheets синхронизация

#### `POST /api/sheets/sync`
- **Описание**: Синхронизация с Google Sheets
- **Требует**: Editor права
- **Body**: `{ spreadsheetId: string, range: string }`

#### `POST /api/sheets/sync-all`
- **Описание**: Синхронизация всех данных
- **Требует**: Admin права

#### `POST /api/sheets/sync-spends`
- **Описание**: Синхронизация расходов
- **Требует**: Editor права

#### `GET /api/sheets/fbm`
- **Описание**: Данные FBM из Sheets

#### `GET /api/sheets/crossgif`
- **Описание**: Данные CROSSGIF из Sheets

---

### SMM

#### `GET /api/smm`
- **Описание**: Получить SMM данные
- **Возвращает**: SmmData[]

#### `POST /api/smm`
- **Описание**: Создать SMM запись
- **Требует**: Editor права

#### `GET /api/smm/projects`
- **Описание**: Список SMM проектов

#### `GET /api/smm/plan-periods`
- **Описание**: Периоды планирования SMM

#### `GET /api/smm/settings`
- **Описание**: Настройки SMM

---

### Аналитика

#### `GET /api/analytics`
- **Описание**: Получить аналитические данные
- **Query**: `type` (daily/weekly/monthly), `startDate`, `endDate`
- **Возвращает**: Analytics

---

### Прочее

#### `POST /api/import`
- **Описание**: Импорт данных из Excel
- **Требует**: Admin права
- **Body**: FormData с Excel файлом

#### `POST /api/seed`
- **Описание**: Инициализация БД тестовыми данными
- **Требует**: Admin права

#### `GET /api/desks`
- **Описание**: Список рабочих столов/десков
- **Возвращает**: Desk[]

#### `POST /api/priemka`
- **Описание**: Данные приёмки
- **Требует**: Editor права

#### `GET /api/priemka-entries`
- **Описание**: Записи приёмки

#### `GET /api/settings`
- **Описание**: Получить настройки системы

#### `POST /api/settings`
- **Описание**: Обновить настройки
- **Требует**: Admin права

#### `GET /api/settings/goals`
- **Описание**: Получить цели/таргеты

#### `POST /api/settings/goals`
- **Описание**: Установить цели
- **Требует**: Admin права

#### `POST /api/data-entry`
- **Описание**: Ввод данных
- **Требует**: Editor права

#### `GET /api/users`
- **Описание**: Список пользователей
- **Требует**: Admin права

---

## Компоненты (src/components)

### Layout компоненты

#### `AppShell`
- **Файл**: `layout/app-shell.tsx`
- **Описание**: Главный layout приложения
- **Props**: `{ children: ReactNode }`
- **Включает**: Header, Sidebar, основной контент

#### `Header`
- **Файл**: `layout/header.tsx`
- **Описание**: Шапка приложения
- **Функции**: Навигация, профиль пользователя, выход

#### `Sidebar`
- **Файл**: `layout/sidebar.tsx`
- **Описание**: Боковое меню
- **Функции**: Навигация по разделам

---

### Dashboard компоненты

#### `MetricCard`
- **Файл**: `dashboard/metric-card.tsx`
- **Props**: 
  ```typescript
  {
    title: string,
    value: number | string,
    change?: number,
    icon?: ReactNode,
    trend?: 'up' | 'down'
  }
  ```
- **Описание**: Карточка метрики

#### `RevenueChart`
- **Файл**: `dashboard/revenue-chart.tsx`
- **Props**: `{ data: ChartData[] }`
- **Описание**: График доходов (Recharts)

#### `CountrySummary`
- **Файл**: `dashboard/country-summary.tsx`
- **Props**: `{ country: Country, metrics: DailyMetrics[] }`
- **Описание**: Сводка по стране

#### `Achievements`
- **Файл**: `dashboard/achievements.tsx`
- **Описание**: Достижения и награды

#### `MotivationalCard`
- **Файл**: `dashboard/motivational-card.tsx`
- **Описание**: Мотивационные сообщения

---

### UI компоненты (Radix UI обертки)

Все UI компоненты находятся в `src/components/ui/`:

- **Button** - Кнопки с вариантами
- **Card** - Карточки контента
- **Dialog** - Модальные окна
- **DropdownMenu** - Выпадающие меню
- **Form** - Формы (React Hook Form)
- **Input** - Поля ввода
- **Label** - Метки для форм
- **Select** - Выбор из списка
- **Table** - Таблицы
- **Tabs** - Табы
- **Textarea** - Многострочный текст
- **Badge** - Бейджи
- **Progress** - Прогресс бары
- **Separator** - Разделители
- **Sheet** - Боковые панели
- **NavigationMenu** - Меню навигации

---

### Provider компоненты

#### `AuthProvider`
- **Файл**: `providers/auth-provider.tsx`
- **Описание**: Context для аутентификации
- **Предоставляет**: 
  - `user: User | null`
  - `isLoading: boolean`
  - `login(username, password)`
  - `logout()`

---

## Скрипты (scripts)

### 1. **import-excel.ts**

#### `importExcelData(filePath: string): Promise<void>`
- **Описание**: Импортирует данные из Excel файла в БД
- **Параметры**: `filePath` - путь к Excel файлу
- **Обрабатывает**: Метрики, сотрудников, расходы

#### `parseExcelFile(filePath: string): WorkBook`
- **Описание**: Парсит Excel файл
- **Возвращает**: Объект WorkBook

---

### 2. **backup-to-turso.ts**

#### `backupToTurso(): Promise<void>`
- **Описание**: Создает бэкап БД в Turso
- **Использует**: Turso API

---

### 3. **migrate-to-postgres.ts**

#### `migrateToPostgres(): Promise<void>`
- **Описание**: Миграция с SQLite на PostgreSQL

---

### 4. **final-import.ts**

#### `finalImport(): Promise<void>`
- **Описание**: Финальный импорт всех данных

---

### 5. **import-direct.ts**

#### `directImport(data: any): Promise<void>`
- **Описание**: Прямой импорт данных в БД

---

### 6. **import-buying-smm.ts**

#### `importBuyingSmm(): Promise<void>`
- **Описание**: Импорт данных покупок и SMM

---

### 7. **import-all-buyer-data.ts**

#### `importAllBuyerData(): Promise<void>`
- **Описание**: Импорт всех данных баера

---

### 8. **sync-production-data.ts**

#### `syncProductionData(): Promise<void>`
- **Описание**: Синхронизация с продакшн данными

---

### 9. **push-to-github.ts**

#### `pushToGithub(message: string): Promise<void>`
- **Описание**: Автоматический push в GitHub

---

### 10. **export-to-json.ts**

#### `exportToJson(outputPath: string): Promise<void>`
- **Описание**: Экспорт БД в JSON

---

### 11. **seed-production.ts**

#### `seedProduction(): Promise<void>`
- **Описание**: Заполнение продакшн БД начальными данными

---

## Страницы (src/app)

### Главная страница (`page.tsx`)

#### `Home(): JSX.Element`
- **Описание**: Главный дашборд
- **Отображает**: Метрики, графики, сводки

### Страницы приложения

- `analytics/page.tsx` - Аналитика
- `buying/page.tsx` - Покупки
- `cabinets/page.tsx` - Кабинеты
- `countries/page.tsx` - Страны
- `countries/[countryId]/add/page.tsx` - Добавление данных по стране
- `finance/page.tsx` - Финансы
- `payroll/page.tsx` - ФОТ
- `settings/page.tsx` - Настройки
- `import/page.tsx` - Импорт
- `login/page.tsx` - Вход
- `help/page.tsx` - Помощь
- `smm/page.tsx` - SMM
- `data-entry/page.tsx` - Ввод данных
- `transactions/page.tsx` - Транзакции
- `agencies/page.tsx` - Агентства

---

## Итого

### Статистика функций:

- **Библиотеки (lib)**: ~35 функций
- **API Routes**: ~90 эндпоинтов
- **Компоненты**: ~45 компонентов
- **Скрипты**: ~15 функций
- **Страницы**: ~15 страниц

**Общее количество**: ~200+ функций и компонентов

---

*Этот документ содержит все основные функции проекта D7-Dash. Для получения детальной информации о каждой функции смотрите исходный код.*
