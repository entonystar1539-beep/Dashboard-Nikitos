# Turso Cloud Database - Пошаговая инструкция

## Что такое Turso?

Turso - это облачная SQLite база данных. Ваши данные будут храниться в облаке, а не в контейнере Railway. При каждом redeploy данные НЕ теряются.

**Преимущества:**
- ☁️ Данные в облаке, не удаляются при redeploy
- 🆓 Бесплатно: 500 баз данных, 9 GB хранилища
- 🚀 Быстрая работа из любой точки мира
- 🔄 Автоматические бэкапы
- 🔒 Безопасность и шифрование

**Время установки:** ~15 минут

---

## ШАГ 1: Установка Turso CLI (2 минуты)

### На MacOS / Linux:

Откройте терминал и выполните:

```bash
curl -sSfL https://get.tur.so/install.sh | bash
```

**Что произойдет:**
- Скрипт скачает и установит Turso CLI
- Вы увидите сообщение "Turso CLI installed successfully"

### На Windows:

Используйте WSL2 (Windows Subsystem for Linux) или скачайте бинарник:

```powershell
# В PowerShell
irm get.tur.so/install.ps1 | iex
```

### Проверка установки:

```bash
turso --version
```

**Ожидаемый результат:**
```
turso version v0.xx.x
```

✅ **CLI установлен!**

---

## ШАГ 2: Регистрация и авторизация (3 минуты)

### 2.1 Авторизация через GitHub

```bash
turso auth login
```

**Что произойдет:**
1. Откроется браузер с страницей авторизации Turso
2. Нажмите "Continue with GitHub" (или другой провайдер)
3. Разрешите доступ Turso к вашему аккаунту
4. Вернитесь в терминал

**В терминале увидите:**
```
Success! Logged in as your-email@example.com
```

✅ **Авторизованы в Turso!**

---

## ШАГ 3: Создание базы данных (2 минуты)

### 3.1 Создайте базу данных

```bash
turso db create d7-dash
```

**Параметры:**
- `d7-dash` - название вашей базы (можете изменить)

**Что произойдет:**
```
Creating database d7-dash in fra (Frankfurt)...
Database d7-dash created successfully!

URL: libsql://d7-dash-[your-username].turso.io
```

✅ **База данных создана!**

### 3.2 (Опционально) Выбрать регион ближе к вам

Если хотите выбрать другой регион (для меньшей задержки):

```bash
# Посмотреть доступные регионы
turso db locations

# Создать базу в нужном регионе
turso db create d7-dash --location ams  # Amsterdam
# или
turso db create d7-dash --location fra  # Frankfurt (рекомендуется для Европы)
```

**Доступные регионы:**
- `fra` - Frankfurt, Germany (Европа) ⭐ Рекомендуется
- `ams` - Amsterdam, Netherlands
- `iad` - Virginia, USA
- `sjc` - San Jose, USA
- `gru` - Sao Paulo, Brazil
- `hkg` - Hong Kong
- `syd` - Sydney, Australia

---

## ШАГ 4: Получение учетных данных (2 минуты)

### 4.1 Получите URL базы данных

```bash
turso db show d7-dash --url
```

**Результат:**
```
libsql://d7-dash-your-username.turso.io
```

📋 **СКОПИРУЙТЕ этот URL** - он вам понадобится!

### 4.2 Создайте токен доступа

```bash
turso db tokens create d7-dash
```

**Результат:**
```
eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE2ODk...очень длинная строка...
```

📋 **СКОПИРУЙТЕ этот токен** - он вам понадобится!

⚠️ **ВАЖНО:** Сохраните токен в безопасном месте. Это как пароль к вашей базе данных!

---

## ШАГ 5: Настройка Railway (3 минуты)

### 5.1 Откройте Railway

1. Перейдите на https://railway.app
2. Откройте свой проект D7-Dash
3. Нажмите на сервис (ваше приложение)

### 5.2 Добавьте переменные окружения

1. Перейдите в раздел **"Variables"** (слева)
2. Нажмите **"New Variable"**

**Добавьте ДВЕ переменные:**

**Переменная 1:**
```
Имя:     TURSO_DATABASE_URL
Значение: libsql://d7-dash-your-username.turso.io
```
(вставьте URL из Шага 4.1)

**Переменная 2:**
```
Имя:     TURSO_AUTH_TOKEN
Значение: eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9...
```
(вставьте токен из Шага 4.2)

### 5.3 Обновите DATABASE_URL (ВАЖНО!)

Найдите переменную `DATABASE_URL` и измените её значение на:

```
file:./prisma/data.db
```

ИЛИ удалите её полностью, если она указывала на другой путь.

**После добавления переменных:**
- Railway автоматически начнет redeploy
- Подождите ~2-3 минуты

✅ **Railway настроен!**

---

## ШАГ 6: Миграция данных в Turso (3 минуты)

### 6.1 Локально запустите миграцию

Вернитесь в терминал в папке проекта:

```bash
# Установите переменные окружения локально
export TURSO_DATABASE_URL="libsql://d7-dash-your-username.turso.io"
export TURSO_AUTH_TOKEN="ваш-токен"

# Запустите миграцию
npm run db:backup
```

**Что произойдет:**
```
🔄 Starting database backup to Turso...

📊 Reading data from local database...
  Found 3 countries
  Found 0 employees
  Found 217 daily metrics
  Found 0 expenses

✅ Backup completed successfully!
📈 Backup Statistics:
   Countries: 3
   Employees: 0
   Daily Metrics: 217
   Expenses: 0
   Timestamp: 2024-01-20T15:30:00.000Z

💾 Data is now safely backed up to Turso cloud!
```

✅ **Данные перенесены в Turso!**

---

## ШАГ 7: Проверка работы (2 минуты)

### 7.1 Проверьте данные в Turso

```bash
# Откройте интерактивную консоль
turso db shell d7-dash

# Выполните проверочные запросы
.tables
```

**Вы должны увидеть:**
```
Country       DailyMetrics  Employee      Expense
```

**Проверьте количество записей:**
```sql
SELECT COUNT(*) FROM DailyMetrics;
SELECT COUNT(*) FROM Country;
```

**Выход из консоли:**
```
.quit
```

### 7.2 Проверьте приложение на Railway

1. Откройте ваше приложение: `https://your-app.railway.app`
2. Проверьте дашборд - данные должны отображаться
3. Попробуйте добавить расход или сотрудника
4. Данные должны сохраниться

✅ **Всё работает!**

---

## ШАГ 8: Проверка сохранности данных (1 минута)

### Тест: Redeploy не удалит данные

1. В Railway нажмите **"Deploy"** → **"Redeploy"**
2. Дождитесь завершения деплоя (~2-3 мин)
3. Откройте приложение
4. **Все ваши данные на месте!** 🎉

---

## Troubleshooting (если что-то пошло не так)

### Проблема 1: "turso: command not found"

**Решение:**
```bash
# Перезагрузите терминал или выполните:
source ~/.bashrc
# или
source ~/.zshrc

# Проверьте PATH
echo $PATH | grep turso
```

### Проблема 2: "Database already exists"

**Решение:**
```bash
# Удалите старую базу
turso db destroy d7-dash

# Создайте заново
turso db create d7-dash
```

### Проблема 3: "Authentication failed"

**Решение:**
```bash
# Выйдите и войдите заново
turso auth logout
turso auth login
```

### Проблема 4: В Railway нет данных после миграции

**Решение:**
```bash
# Проверьте что переменные установлены правильно
turso db show d7-dash

# Убедитесь что в Railway:
# TURSO_DATABASE_URL = точно такой же URL
# TURSO_AUTH_TOKEN = валидный токен

# Пересоздайте токен если нужно
turso db tokens create d7-dash
```

### Проблема 5: "LibsqlError: SQLITE_IOERR"

**Решение:**
Это значит приложение пытается писать в локальный файл вместо Turso.

Проверьте в Railway:
1. `TURSO_DATABASE_URL` установлен
2. `TURSO_AUTH_TOKEN` установлен
3. `DATABASE_URL` НЕ указывает на локальный файл

---

## Полезные команды Turso

### Просмотр всех баз данных
```bash
turso db list
```

### Информация о базе
```bash
turso db show d7-dash
```

### Создание дополнительных токенов
```bash
turso db tokens create d7-dash --expiration 30d
```

### Создание read-only токена
```bash
turso db tokens create d7-dash --read-only
```

### Удаление базы данных
```bash
turso db destroy d7-dash
```

### Мониторинг использования
```bash
turso account get
```

---

## Автоматические бэкапы (опционально)

### Настройка ежедневных бэкапов через GitHub Actions

Создайте файл `.github/workflows/backup.yml`:

```yaml
name: Daily Database Backup

on:
  schedule:
    - cron: '0 3 * * *'  # Каждый день в 3:00 UTC
  workflow_dispatch:      # Можно запустить вручную

jobs:
  backup:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3

      - uses: actions/setup-node@v3
        with:
          node-version: '18'

      - name: Install dependencies
        run: npm install

      - name: Run backup
        run: npm run db:backup
        env:
          TURSO_DATABASE_URL: ${{ secrets.TURSO_DATABASE_URL }}
          TURSO_AUTH_TOKEN: ${{ secrets.TURSO_AUTH_TOKEN }}

      - name: Upload backup artifact
        uses: actions/upload-artifact@v3
        with:
          name: database-backup
          path: backups/
          retention-days: 30
```

**Добавьте секреты в GitHub:**
1. Откройте репозиторий на GitHub
2. Settings → Secrets and variables → Actions
3. New repository secret:
   - `TURSO_DATABASE_URL`
   - `TURSO_AUTH_TOKEN`

---

## Мониторинг и статистика

### Просмотр статистики использования

```bash
# Общая статистика аккаунта
turso account get

# Статистика конкретной базы
turso db inspect d7-dash
```

**Пример вывода:**
```
Database: d7-dash
Location: fra
Size: 2.3 MB
Rows: ~220
```

---

## Что дальше?

✅ Turso настроен и работает!

**Ваши данные теперь:**
- Хранятся в облаке Turso
- Не удаляются при redeploy
- Автоматически реплицируются
- Доступны из любой точки мира

**Рекомендации:**
1. Настройте автоматические бэкапы (см. выше)
2. Периодически проверяйте `turso account get`
3. Следите за лимитами бесплатного тарифа
4. При необходимости переходите на платный план

---

## Лимиты бесплатного тарифа

| Параметр | Бесплатно | Платно (Starter) |
|----------|-----------|------------------|
| Базы данных | 500 | Неограничено |
| Хранилище | 9 GB | 25 GB |
| Локации | 3 | Неограничено |
| Rows read/month | 1 млрд | 10 млрд |
| Rows written/month | 25 млн | 250 млн |
| Цена | $0 | $29/месяц |

**Для вашего проекта D7-Dash бесплатного тарифа более чем достаточно!**

---

## Поддержка

- 📚 Документация: https://docs.turso.tech
- 💬 Discord: https://discord.gg/turso
- 🐦 Twitter: https://twitter.com/tursodatabase
- 📧 Email: support@turso.tech

---

**Готово! Ваша база данных теперь в облаке и защищена от потерь! 🎉**
