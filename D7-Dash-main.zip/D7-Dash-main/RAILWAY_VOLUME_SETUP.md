# 🚂 Настройка Railway Volume для сохранения базы данных

## Пошаговая инструкция

### Шаг 1: Откройте проект в Railway

1. Перейдите на [railway.app](https://railway.app)
2. Войдите в свой аккаунт
3. Выберите свой проект **D7-Dash**

### Шаг 2: Создайте Volume (Постоянное хранилище)

1. В dashboard проекта найдите раздел **"Service"** (ваше приложение)
2. Нажмите на ваш сервис
3. Перейдите на вкладку **"Volumes"**
4. Нажмите кнопку **"+ New Volume"**

### Шаг 3: Настройте Volume

Заполните параметры:

```
Volume Name: database-storage
Mount Path: /data
```

**Важно:** Mount Path ОБЯЗАТЕЛЬНО должен быть `/data`

### Шаг 4: Обновите переменные окружения

1. Перейдите на вкладку **"Variables"** в вашем сервисе
2. Добавьте или обновите переменную:

```
DATABASE_URL=file:/data/data.db
```

**Или** если переменная уже есть:
- Найдите `DATABASE_URL`
- Измените значение на `file:/data/data.db`

### Шаг 5: Скопируйте существующую базу на Volume

Есть два варианта:

#### Вариант A: Через Railway CLI (Рекомендуется)

1. Установите Railway CLI (если еще не установлен):
```bash
npm install -g @railway/cli
```

2. Залогиньтесь:
```bash
railway login
```

3. Подключитесь к проекту:
```bash
cd /path/to/D7-Dash
railway link
```

4. Скопируйте базу данных на Volume:
```bash
# Откройте shell в контейнере
railway run bash

# Скопируйте БД
cp prisma/data.db /data/data.db

# Проверьте
ls -la /data/
```

#### Вариант B: Через Git (Если БД в репозитории)

1. Убедитесь, что `prisma/data.db` закоммичена в Git:
```bash
git add prisma/data.db
git commit -m "Add database to repo"
git push
```

2. После деплоя Railway автоматически создаст БД
3. Добавьте команду миграции в `package.json`:

```json
{
  "scripts": {
    "build": "next build && npm run migrate-db",
    "migrate-db": "cp prisma/data.db /data/data.db || true"
  }
}
```

### Шаг 6: Деплой изменений

1. **Закоммитьте изменения** (если меняли код):
```bash
git add .
git commit -m "chore: Configure Railway Volume for database"
git push
```

2. Railway автоматически запустит новый деплой

3. **Дождитесь завершения** деплоя (обычно 2-3 минуты)

### Шаг 7: Проверка

1. Откройте ваше приложение в браузере
2. Проверьте, что данные отображаются
3. Добавьте тестовый расход или сотрудника
4. **Важно:** Запустите редеплой вручную и проверьте, что данные НЕ пропали

## ✅ Готово!

Теперь ваша база данных сохраняется между деплоями в постоянном хранилище `/data`.

## 🔍 Проверка Volume

Чтобы убедиться, что Volume работает:

```bash
# Подключитесь к контейнеру
railway run bash

# Проверьте, что /data примонтирован
df -h | grep /data

# Посмотрите содержимое
ls -lah /data/

# Проверьте размер БД
du -h /data/data.db
```

## 📊 Мониторинг размера Volume

1. Railway показывает использование Volume в разделе **"Usage"**
2. Бесплатный план: до 1GB Volume
3. Рекомендую периодически проверять размер БД

## 🔧 Troubleshooting

### Проблема: "Database not found"

**Решение:**
```bash
railway run bash
# Проверьте путь
echo $DATABASE_URL
ls -la /data/
# Если БД нет, скопируйте:
cp prisma/data.db /data/data.db
```

### Проблема: "Permission denied"

**Решение:**
```bash
railway run bash
chmod 755 /data
chmod 644 /data/data.db
```

### Проблема: После деплоя данные пропали

**Причины:**
1. Volume не примонтирован → проверьте Mount Path
2. Путь к БД неправильный → проверьте DATABASE_URL
3. БД записывается не в /data → проверьте логи

**Решение:**
```bash
# Проверьте логи деплоя
railway logs

# Убедитесь, что DATABASE_URL правильный
railway variables
```

## 🎯 Важные моменты

✅ **DO:**
- Используйте путь `/data` для Volume
- Регулярно делайте бэкапы БД
- Мониторьте размер Volume

❌ **DON'T:**
- НЕ удаляйте Volume без бэкапа
- НЕ меняйте Mount Path после создания
- НЕ храните чувствительные данные без шифрования

## 📥 Бэкап БД

### Автоматический бэкап

Добавьте скрипт в `package.json`:

```json
{
  "scripts": {
    "db:backup": "railway run 'cat /data/data.db' > backup-$(date +%Y%m%d).db"
  }
}
```

Запуск:
```bash
npm run db:backup
```

### Ручной бэкап

```bash
railway run cat /data/data.db > backup-$(date +%Y%m%d).db
```

## 🔄 Восстановление БД

```bash
# Загрузить БД обратно
railway run sh -c 'cat > /data/data.db' < backup-20260120.db

# Проверить
railway run ls -lah /data/data.db
```

## 📞 Полезные ссылки

- [Railway Volumes Docs](https://docs.railway.app/guides/volumes)
- [Railway CLI Docs](https://docs.railway.app/develop/cli)
- [SQLite Best Practices](https://www.sqlite.org/draft/bestpractice.html)

---

**Готово!** Теперь ваша база данных в безопасности! 🎉
